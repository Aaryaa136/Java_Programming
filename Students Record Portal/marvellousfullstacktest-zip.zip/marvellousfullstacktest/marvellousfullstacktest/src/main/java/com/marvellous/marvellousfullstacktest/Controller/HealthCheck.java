package com.marvellous.marvellousfullstacktest.Controller;

public class HealthCheck
{

}
