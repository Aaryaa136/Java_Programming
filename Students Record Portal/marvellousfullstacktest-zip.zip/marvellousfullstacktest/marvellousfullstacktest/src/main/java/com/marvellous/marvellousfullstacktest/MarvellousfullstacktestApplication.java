package com.marvellous.marvellousfullstacktest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarvellousfullstacktestApplication
{

	public static void main(String[] args)
    {
		SpringApplication.run(MarvellousfullstacktestApplication.class, args);
	}

}
