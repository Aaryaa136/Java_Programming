package com.marvellous.marvellousfullstacktest.Entity;

import lombok.Getter;
import lombok.Setter;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "BatchDetails") //ORM
@Getter
@Setter
//POJO CLass
public class BatchEntry
{
    private ObjectId id;
    private String name;
    private int fees;
}
